/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.ATMTuto;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author bhavana
 */
public abstract class BankClass implements ITransaction {
    
    int AccountNo;
    int Pin;
    int _balance;
     boolean _success;
    
    // For Connection
    Connection con = null;
    PreparedStatement put = null;
    ResultSet Rs = null;
    Statement st = null;
    
    public int getBalance()
            {
                
                return _balance ;
            }
    
    
    public void setAccountNo(int Actm)
    {
        AccountNo = Actm;
    }
    
    
    public int getAccountNo()
    {
       return  AccountNo ;
    }
    
     public void setPin(int pin)
    {
        Pin = pin;
    }
     
     public boolean getStatus()
    {
        return _success;
    }
}
