/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.ATMTuto;

import java.sql.Connection;
import java.sql.DriverManager;
/**
 *
 * @author bhavana
 */
public class ATMConnection {
    Connection con =null;
    public Connection getConnection() throws Exception
    {
         
         try{
         Class.forName("com.mysql.cj.jdbc.Driver");
         con =  DriverManager.getConnection
        ("jdbc:mysql://localhost:3307/finaldb","root","your_password");
         }
         catch (Exception e)
         {
             throw new Exception(e);
         }
        return con;
    }
    
    public void Close()
    {
        try{
        con.close();
        }
        catch (Exception e)
        {
            
        }
        
    }
    
}
