package main.java.ATMTuto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class WithdrawClass extends BankClass {
    int _withdraw;

    public int getWithdraw() {
        return _withdraw;
    }

    public void setWithdraw(int withdraw) {
        this._withdraw = withdraw;
    }
    @Override
    public void Execute() {
        try {
            withdrawMoney();
            _success = true;
        } catch (Exception e) {
            // Handle the exception appropriately (e.g., logging)
        }
    }

    public void withdrawMoney() throws Exception {
       
        try {
            ATMConnection ac = new ATMConnection();
            LocalDateTime today = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
            String MyDate = today.format(formatter);
            con = ac.getConnection();
            PreparedStatement Add = con.prepareStatement("INSERT INTO transactiontb (AccNum, Amount, Type, TDate) VALUES (?, ?, ?, ?)");
            Add.setInt(1, this.AccountNo);
            Add.setInt(2, _withdraw);
            Add.setString(3, "Withdraw");
            Add.setString(4, MyDate);
            Add.executeUpdate();
            
            Add = con.prepareStatement("UPDATE signuptb SET Balance = Balance - ? WHERE AccNumTb = ?");
            Add.setInt(1, _withdraw);
            Add.setInt(2, this.AccountNo);
            Add.executeUpdate();
        } catch (Exception e) {
            throw new Exception(e);
        } finally {
            if (con != null) {
                con.close();
            }
        }
    }
}
