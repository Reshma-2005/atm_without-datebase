/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.ATMTuto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author bhavana
 */
public class BalanceClass extends BankClass {
    
    
    @Override
    public void Execute() 
    {
           String query = "Select Balance from signuptb where AccNumTb ="+this.AccountNo+";";
            try{
            
                  ATMConnection ac = new ATMConnection();
               // Class.forName("com.mysql.cj.jdbc.Driver");
                con = ac.getConnection();
                st = con.createStatement();
                Rs = st.executeQuery(query);
                if(Rs.next()){
                    _balance = Rs.getInt(1);
                   // BallanceLb.setText(""+OldBalalnce);
                }
            }catch(Exception e){
               //throw new  Exception(e);
            }   
    }
}
