/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package main.java.ATMTuto;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import javax.swing.JOptionPane;

/*
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
*/
/**
 *
 * @author bhavana
 */
public class DepositClass extends BankClass{
    int _deposit;
   
    public void setDeposit(int deposit)
    {
        _deposit = deposit;
    }
    
    @Override
    public void Execute()
    {
           
           // String query = "Select Balance from signuptb where AccNumTb ="+this.AccountNo+";";
            try{
                 depositeMoney();
                 _success = true;
                 /*
                 ATMConnection ac = new ATMConnection();
                con = ac.getConnection();
                st = con.createStatement();
                Rs = st.executeQuery(query);
                if(Rs.next()){
                    _balance = Rs.getInt(1);
                }
                ac.Close();
               */
            }catch(Exception e){
                
            }   
    }
    
     public  void depositeMoney() throws Exception{
        try{
              
//  getDateTime();
                  ATMConnection ac = new ATMConnection();
                LocalDateTime today = LocalDateTime.now();
                DateTimeFormatter formater = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
                String MyDate = today.format(formater);
               // Class.forName("com.mysql.cj.jdbc.Driver");
              //  con = DriverManager.getConnection("jdbc:mysql://localhost:4306/finaldb","root","Vani@2004");
              con = ac.getConnection();
              PreparedStatement Add = con.prepareStatement("insert into transactiontb (AccNum, Amount, Type, TDate) VALUES (?, ?, ?, ?)");
                Add.setInt(1, this.AccountNo);
                Add.setInt(2, _deposit);
                Add.setString(3, "Deposit");
                
                Add.setString(4, MyDate);
                int row = Add.executeUpdate();
                
                   Add = con.prepareStatement("update signuptb set balance = balance + ? where AccNumTb = ?");
                   Add.setInt(2, this.AccountNo);
                    Add.setInt(1, _deposit);
                     Add.executeUpdate();
                ac.Close();
            }catch(Exception e){
              throw new Exception (e);
            }
    }
    
}
